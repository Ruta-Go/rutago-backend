"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("Vehiculos", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      placa: {
        type: Sequelize.STRING,
        unique: true,
      },
      marca: {
        type: Sequelize.STRING,
      },
      modelo: {
        type: Sequelize.STRING,
      },
      color: {
        type: Sequelize.STRING,
      },
      capacidadPasajeros: {
        type: Sequelize.INTEGER,
      },
      tipoVehiculo: {
        type: Sequelize.STRING,
      },
      numeroInterno: {
        type: Sequelize.STRING,
      },
      entidadId: {
        type: Sequelize.INTEGER,
        references: { model: "Entidades", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "SET NULL",
      },
      estadoId: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("Vehiculos");
  },
};
