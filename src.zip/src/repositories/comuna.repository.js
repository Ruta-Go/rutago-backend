const { Op } = require("sequelize");
const { Comuna } = require("../models");

exports.obtenerPorId = async (id) => {
  const comuna = await Comuna.findByPk(id);
  if (!comuna) throw new Error("COMUNA_NO_ENCONTRADA");
  return comuna;
};

exports.crearComuna = async (datos) => {
  return await Comuna.create(datos);
};

exports.actualizarComuna = async (id, datos) => {
  const comuna = await Comuna.findByPk(id);
  if (!comuna) throw new Error("COMUNA_NO_ENCONTRADA");
  return await comuna.update(datos);
};

exports.eliminarComuna = async (id) => {
  const comuna = await Comuna.findByPk(id);
  if (!comuna) throw new Error("COMUNA_NO_ENCONTRADA");
  await comuna.destroy();
  return true;
};

exports.obtenerTodasConPaginacion = async (
  limit,
  offset,
  q,
  sortBy = "nombre",
  sortOrder = "ASC",
) => {
  const where = {};
  if (q) {
    where.nombre = { [Op.like]: `%${q}%` };
  }
  return await Comuna.findAndCountAll({
    where,
    limit,
    offset,
    order: [[sortBy, sortOrder]],
    distinct: true,
  });
};
